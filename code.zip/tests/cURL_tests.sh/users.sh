#!/bin/bash

GET all users
curl -s -X GET http://localhost:8000/users.php | jq
echo

POST new user
curl -s -X POST -H "Content-Type: application/json" \
-d '{"name":"David Lee","email":"david.lee@example.com","role":"User"}' \
http://localhost:8000/users.php | jq
echo

PUT update user
curl -s -X PUT -H "Content-Type: application/json" \
-d '{"id":1,"name":"David Lee","email":"david.lee@example.com","role":"Admin"}' \
http://localhost:8000/users.php | jq
echo

DELETE user
curl -s -X DELETE -d "id=1" http://localhost:8000/users.php | jq
echo