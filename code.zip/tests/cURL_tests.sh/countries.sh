#!/bin/bash
FILE="countries.json"

GET all countries (simulate API response)
curl -s -X GET http://localhost:8000/countries.php | jq
echo

GET specific country by ID using JSON file
jq '.[] | select(.id==1)' $FILE
echo
jq '.[] | select(.id==2)' $FILE
echo
jq '.[] | select(.id==3)' $FILE
echo

POST new country (simulate adding a new country)
NEW_COUNTRY='{"id":4,"name":"Germany","capital":"Berlin","region":"Europe","population":83000000}'
curl -s -X POST -H "Content-Type: application/json" -d "$NEW_COUNTRY" http://localhost:8000/countries.php | jq
echo

PUT update country (simulate updating country ID 1)
UPDATE_COUNTRY='{"id":1,"name":"USA","capital":"Washington, D.C.","region":"North America","population":333000000}'
curl -s -X PUT -H "Content-Type: application/json" -d "$UPDATE_COUNTRY" http://localhost:8000/countries.php | jq
echo

DELETE country (simulate deleting country ID 4)
curl -s -X DELETE -d "id=4" http://localhost:8000/countries.php | jq
echo