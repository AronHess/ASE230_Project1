#!/bin/bash

GET all trivia questions
curl -s -X GET http://localhost:8000/trivia.php | jq
echo

POST new trivia question
curl -s -X POST -H "Content-Type: application/json" \
-d '{"question":"What is 2+2?","answer":"4","category":"Math"}' \
http://localhost:8000/trivia.php | jq
echo

PUT update trivia question
curl -s -X PUT -H "Content-Type: application/json" \
-d '{"id":1,"question":"What is 3+3?","answer":"6","category":"Math"}' \
http://localhost:8000/trivia.php | jq
echo

DELETE trivia question
curl -s -X DELETE -d "id=1" http://localhost:8000/trivia.php | jq
echo
