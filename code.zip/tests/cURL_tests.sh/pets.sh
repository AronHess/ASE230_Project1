#!/bin/bash

GET all pets
curl -s -X GET http://localhost:8000/pets.php | jq
echo

POST new pet
curl -s -X POST -H "Content-Type: application/json" \
-d '{"name":"Luna","species":"Cat","age":2,"owner":"David"}' \
http://localhost:8000/pets.php | jq
echo

PUT update pet
curl -s -X PUT -H "Content-Type: application/json" \
-d '{"id":1,"name":"Luna","species":"Cat","age":3,"owner":"David"}' \
http://localhost:8000/pets.php | jq
echo

DELETE pet
curl -s -X DELETE -d "id=1" http://localhost:8000/pets.php | jq
echo