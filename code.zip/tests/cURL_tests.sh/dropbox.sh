#!/bin/bash
FILE="dropbox.json"

curl -s -X GET http://localhost:8000/dropbox.php | jq
echo

jq '.[] | select(.id==1)' $FILE
echo

NEW_FILE='{"filename":"presentation.pptx","size":2048000,"uploaded":"2025-10-10","owner":"David Lee"}'
curl -s -X POST -H "Content-Type: application/json" -d "$NEW_FILE" http://localhost:8000/dropbox.php | jq
echo

UPDATE_FILE='{"id":1,"filename":"report_updated.pdf","size":1050000,"uploaded":"2025-10-01"}'
curl -s -X PUT -H "Content-Type: application/json" -d "$UPDATE_FILE" http://localhost:8000/dropbox.php | jq
echo

curl -s -X DELETE -d "id=4" http://localhost:8000/dropbox.php | jq
echo
