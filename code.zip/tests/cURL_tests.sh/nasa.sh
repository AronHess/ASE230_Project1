#!/bin/bash

curl -s -X GET http://localhost:8000/nasa.php | jq
echo

curl -s -X POST -H "Content-Type: application/json" \
-d '{"mission_name":"Europa Clipper","launch_date":"2025-10-10","description":"Mission to study Europa","status":"Planned"}' \
http://localhost:8000/nasa.php | jq
echo