#!/bin/bash

TOKEN="abcdef1234567890"
FILE="spotify.json"

GET all artists
curl -s -X GET -H "Authorization: Bearer $TOKEN" http://localhost:8000/spotify.php | jq
echo

GET specific artist by name
ARTIST="Imagine Dragons"
jq --arg a "$ARTIST" '.[] | select(.name==$a)' $FILE
echo

ARTIST="Adele"
jq --arg a "$ARTIST" '.[] | select(.name==$a)' $FILE
echo

ARTIST="Drake"
jq --arg a "$ARTIST" '.[] | select(.name==$a)' $FILE
echo