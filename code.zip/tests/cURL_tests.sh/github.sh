#!/bin/bash

TOKEN="1234567890abcdef"
FILE="github.json"

GET all GitHub users (simulate API using JSON file)
curl -s -X GET -H "Authorization: Bearer $TOKEN" http://localhost:8000/github.php | jq
echo

GET specific GitHub user by username
USERNAME="octocat"
jq --arg u "$USERNAME" '.[] | select(.login==$u)' $FILE
echo

USERNAME="torvalds"
jq --arg u "$USERNAME" '.[] | select(.login==$u)' $FILE
echo