#!/bin/bash

GET all weather records
curl -s -X GET http://localhost:8000/weather.php | jq
echo

POST new weather record
curl -s -X POST -H "Content-Type: application/json" \
-d '{"city":"Miami","temperature":30,"condition":"Sunny","humidity":55}' \
http://localhost:8000/weather.php | jq
echo

PUT update weather record
curl -s -X PUT -H "Content-Type: application/json" \
-d '{"id":1,"city":"Miami","temperature":32,"condition":"Sunny","humidity":50}' \
http://localhost:8000/weather.php | jq
echo

DELETE weather record
curl -s -X DELETE -d "id=1" http://localhost:8000/weather.php | jq
echo