#!/bin/bash
FILE="indeed.json"

curl -s -X GET http://localhost:8000/indeed.php | jq
echo

jq '.[] | select(.id==1)' $FILE
echo

NEW_JOB='{"title":"Network Engineer","company":"NetTech","location":"Dallas, TX","salary":"$100000","posted":"2025-10-10"}'
curl -s -X POST -H "Content-Type: application/json" -d "$NEW_JOB" http://localhost:8000/indeed.php | jq
echo

UPDATE_JOB='{"id":1,"title":"Software Engineer Updated","company":"TechCorp","location":"New York, NY","salary":"$125000"}'
curl -s -X PUT -H "Content-Type: application/json" -d "$UPDATE_JOB" http://localhost:8000/indeed.php | jq
echo

curl -s -X DELETE -d "id=4" http://localhost:8000/indeed.php | jq
echo