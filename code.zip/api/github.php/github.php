<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$headers = apache_request_headers();
if (!isset($headers['Authorization'])) {
    http_response_code(401);
    echo json_encode(["message" => "Missing Authorization header"]);
    exit;
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$validToken = "1234567890abcdef"; // Replace with your actual secret token

if ($token !== $validToken) {
    http_response_code(403);
    echo json_encode(["message" => "Invalid token"]);
    exit;
}

$username = $_GET['username'] ?? '';
if (!$username) {
    http_response_code(400);
    echo json_encode(["message" => "Missing GitHub username"]);
    exit;
}

$url = "https://api.github.com/users/" . urlencode($username);
$options = [
    "http" => [
        "header" => "User-Agent: PHP\r\n"
    ]
];
$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);

if ($response === false) {
    http_response_code(404);
    echo json_encode(["message" => "GitHub user not found"]);
    exit;
}

echo $response;
?>