<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$file = 'trivia.json';
$data = json_decode(file_get_contents($file), true);
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $question = array_filter($data, fn($q) => $q['id'] === $id);
            echo json_encode(array_values($question));
        } else {
            echo json_encode($data);
        }
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $input['id'] = end($data)['id'] + 1;
        $data[] = $input;
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Question added successfully", "question" => $input]);
        break;
    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);
        foreach ($data as &$question) {
            if ($question['id'] == $input['id']) {
                $question = array_merge($question, $input);
            }
        }
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Question updated successfully"]);
        break;
    case 'DELETE':
        parse_str(file_get_contents("php://input"), $_DELETE);
        $id = intval($_DELETE['id']);
        $data = array_filter($data, fn($q) => $q['id'] != $id);
        file_put_contents($file, json_encode(array_values($data), JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Question deleted successfully"]);
        break;
    default:
        http_response_code(405);
        echo json_encode(["message" => "Method not allowed"]);
}
?>