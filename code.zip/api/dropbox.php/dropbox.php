<?php
header("Content-Type: application/json");
$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("dropbox.json"), true);

if($method == "GET"){
    if(isset($_GET['id'])){
        $file = array_filter($data, fn($f) => $f['id'] == $_GET['id']);
        echo json_encode(array_values($file));
    } else {
        echo json_encode($data);
    }
}

if($method == "POST"){
    $input = json_decode(file_get_contents("php://input"), true);
    $input['id'] = count($data) + 1;
    $data[] = $input;
    file_put_contents("dropbox.json", json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode($input);
}

if($method == "PUT"){
    $input = json_decode(file_get_contents("php://input"), true);
    foreach($data as &$f){
        if($f['id'] == $input['id']){
            $f = array_merge($f, $input);
        }
    }
    file_put_contents("dropbox.json", json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode($input);
}

if($method == "DELETE"){
    parse_str(file_get_contents("php://input"), $input);
    $data = array_filter($data, fn($f) => $f['id'] != $input['id']);
    file_put_contents("dropbox.json", json_encode(array_values($data), JSON_PRETTY_PRINT));
    echo json_encode($input);
}
?>