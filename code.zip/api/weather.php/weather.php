<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$file = 'weather.json';
$data = json_decode(file_get_contents($file), true);
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $city = array_filter($data, fn($c) => $c['id'] === $id);
            echo json_encode(array_values($city));
        } else {
            echo json_encode($data);
        }
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $input['id'] = end($data)['id'] + 1;
        $data[] = $input;
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Weather record added successfully", "weather" => $input]);
        break;
    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);
        foreach ($data as &$city) {
            if ($city['id'] == $input['id']) {
                $city = array_merge($city, $input);
            }
        }
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Weather record updated successfully"]);
        break;
    case 'DELETE':
        parse_str(file_get_contents("php://input"), $_DELETE);
        $id = intval($_DELETE['id']);
        $data = array_filter($data, fn($c) => $c['id'] != $id);
        file_put_contents($file, json_encode(array_values($data), JSON_PRETTY_PRINT));
        echo json_encode(["message" => "Weather record deleted successfully"]);
        break;
    default:
        http_response_code(405);
        echo json_encode(["message" => "Method not allowed"]);
}
?>