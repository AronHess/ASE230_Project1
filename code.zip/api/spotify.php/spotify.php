<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$headers = apache_request_headers();
if (!isset($headers['Authorization'])) {
    http_response_code(401);
    echo json_encode(["message" => "Missing Authorization header"]);
    exit;
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$validToken = "abcdef1234567890"; // Replace with your actual token

if ($token !== $validToken) {
    http_response_code(403);
    echo json_encode(["message" => "Invalid token"]);
    exit;
}

$artist = $_GET['artist'] ?? '';
if (!$artist) {
    http_response_code(400);
    echo json_encode(["message" => "Missing artist name"]);
    exit;
}

// Simulate Spotify API response
$spotifyData = [
    "name" => $artist,
    "followers" => rand(1000, 1000000),
    "popularity" => rand(1, 100),
    "genres" => ["pop", "rock"]
];

echo json_encode($spotifyData);
?>