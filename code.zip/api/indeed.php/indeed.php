<?php
header("Content-Type: application/json");
$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("indeed.json"), true);

if($method == "GET"){
    if(isset($_GET['id'])){
        $job = array_filter($data, fn($j) => $j['id'] == $_GET['id']);
        echo json_encode(array_values($job));
    } else {
        echo json_encode($data);
    }
}

if($method == "POST"){
    $input = json_decode(file_get_contents("php://input"), true);
    $input['id'] = count($data) + 1;
    $data[] = $input;
    file_put_contents("indeed.json", json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode($input);
}

if($method == "PUT"){
    $input = json_decode(file_get_contents("php://input"), true);
    foreach($data as &$j){
        if($j['id'] == $input['id']){
            $j = array_merge($j, $input);
        }
    }
    file_put_contents("indeed.json", json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode($input);
}

if($method == "DELETE"){
    parse_str(file_get_contents("php://input"), $input);
    $data = array_filter($data, fn($j) => $j['id'] != $input['id']);
    file_put_contents("indeed.json", json_encode(array_values($data), JSON_PRETTY_PRINT));
    echo json_encode($input);
}
?>