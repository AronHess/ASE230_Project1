CREATE TABLE countries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    capital VARCHAR(50) NOT NULL,
    region VARCHAR(50) NOT NULL,
    population INT NOT NULL
);

CREATE TABLE nasa_missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mission_name VARCHAR(100) NOT NULL,
    launch_date DATE NOT NULL,
    description VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL
);

CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    species VARCHAR(50) NOT NULL,
    age INT NOT NULL,
    owner VARCHAR(50) NOT NULL
);

CREATE TABLE trivia_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    major VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

CREATE TABLE weather (
    id INT AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(50) NOT NULL,
    temperature INT NOT NULL,
    condition VARCHAR(50) NOT NULL,
    humidity INT NOT NULL
);

CREATE TABLE github_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    public_repos INT NOT NULL,
    followers INT NOT NULL,
    following INT NOT NULL
);

CREATE TABLE spotify_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artist VARCHAR(100) NOT NULL,
    followers INT NOT NULL,
    popularity INT NOT NULL,
    genre VARCHAR(50) NOT NULL
);

CREATE TABLE quiz (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    questions INT NOT NULL,
    difficulty VARCHAR(50) NOT NULL
);

CREATE TABLE restcountries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    capital VARCHAR(50) NOT NULL,
    region VARCHAR(50) NOT NULL,
    population INT NOT NULL,
    flag VARCHAR(10) NOT NULL
);

CREATE TABLE indeed_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    salary VARCHAR(50) NOT NULL,
    posted DATE NOT NULL
);

CREATE TABLE dropbox_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(100) NOT NULL,
    size BIGINT NOT NULL,
    uploaded DATE NOT NULL,
    owner VARCHAR(50) NOT NULL
);